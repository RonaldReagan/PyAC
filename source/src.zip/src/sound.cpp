// sound.cpp: uses OpenAL, some code chunks are from devmaster.net and gamedev.net

#include "cube.h"

