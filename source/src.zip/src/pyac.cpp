#include "cube.h"

/*Start Python*/
PyObject *pyac_acmod;
PyObject *pyac_modules;

static PyObject *pyac_regmodule(PyObject *self, PyObject *args)
{
    PyObject *moddict;
    if(!PyArg_ParseTuple(args,  "O", &moddict))
        return NULL;
    
    Py_INCREF(moddict);
    PyList_Append(pyac_modules, moddict);
    return Py_BuildValue("");
}

#ifndef STANDALONE
static PyObject* pyac_conout(PyObject *self, PyObject *args)
{
    char *s;
    if(!PyArg_ParseTuple(args,  "s", &s))
        return NULL;
    
    conoutf(s);
    return Py_BuildValue("");
}

static PyObject *pyac_csexecute(PyObject *self, PyObject *args)
{
    char *s;
    if(!PyArg_ParseTuple(args,  "s", &s))
        return NULL;
    
    execute(s);
    return Py_BuildValue("");
}

void execPython(char *s) {
    PyRun_SimpleString(s);
}
COMMAND(execPython, ARG_1STR);

extern void pyac_setvar(const char *name, PyObject *val, bool dofunc);
static PyObject *pyac_setgamevar(PyObject *self, PyObject *args) {
    char *name;
    PyObject *val;
    if(!PyArg_ParseTuple(args,  "sO", &name, &val))
        return NULL;
    
    Py_INCREF(val);
    pyac_setvar(name,val,false);
    Py_XDECREF(val);
}
extern PyObject *pyac_getvar(const char *name);
static PyObject *pyac_getgamevar(PyObject *self, PyObject *args) {
    char *name;
    if(!PyArg_ParseTuple(args,  "s", &name))
        return NULL;
    
    return pyac_getvar(name);
}

extern void pyac_startinput(PyObject *callback, char *i);
static PyObject *pyac_getinput(PyObject *self, PyObject *args) {
    PyObject *callback;
    char *i;
    if(!PyArg_ParseTuple(args,  "Os", &callback, &i))
        return NULL;
    
    Py_INCREF(callback);
    pyac_startinput(callback,i);
}
#endif


extern PyObject *pyac_getclientinfo(int cn);
extern PyObject *pyac_getallclientsinfo();
extern void sendservmsg(const char *msg, int client=-1);

static PyObject *pyac_sendmsg(PyObject *self, PyObject *args) {
    char *msg;
    int cn = -1;
    if(!PyArg_ParseTuple(args,  "s|i", &msg,&cn))
        return NULL;
    
    sendservmsg(msg,cn);
    return Py_None;
}

static PyObject *pyac_getclient(PyObject *self, PyObject *args) {
    int *cn;
    if(!PyArg_ParseTuple(args,  "i", &cn))
        return NULL;
    
    return pyac_getclientinfo(*cn);
}
static PyObject *pyac_getallclients(PyObject *self) {
    return pyac_getallclientsinfo();
}

static PyObject *pyac_logline(PyObject *self, PyObject *args) {
    char *s;
    int level = ACLOG_INFO;
    if(!PyArg_ParseTuple(args,  "s|i", &s, &level))
        return NULL;
    logline(level, s);
    
}

extern void disconnect_client(int n, int reason);
static PyObject *pyac_discclient(PyObject *self, PyObject *args) {
    int cn, reason = DISC_NONE;
    if(!PyArg_ParseTuple(args,  "i|i", &cn, &reason))
        return NULL;
    disconnect_client(cn, reason);
    
}

extern void forceSuicide(int cn);
static PyObject *pyac_forceSuicide(PyObject *self, PyObject *args) {
    int cn;
    if(!PyArg_ParseTuple(args,  "i", &cn))
        return NULL;
    forceSuicide(cn);
    
}


static PyMethodDef pyac_MainMethods[] = {
    {"register", pyac_regmodule, METH_VARARGS, "Registers a dictionary of python event callbacks."},
    {NULL, NULL, 0, NULL}
};
#ifndef STANDALONE
static PyMethodDef pyac_ClientMainMethods[] = {
    {"conout", pyac_conout, METH_VARARGS, "Prints to the console."},
    {"cubescript", pyac_csexecute, METH_VARARGS, "Executes the given cubescript string"},
    {"setvar", pyac_setgamevar, METH_VARARGS, "Sets the game variable."},
    {"getvar", pyac_getgamevar, METH_VARARGS, "Gets the game variable."},
    {"getinput", pyac_getinput, METH_VARARGS, "Provides access to user input."},
    {NULL, NULL, 0, NULL}
};
#else
static PyMethodDef pyac_ClientMainMethods[] = {
    {NULL, NULL, 0, NULL}
};
#endif

static PyMethodDef pyac_ServerMainMethods[] = {
    {"logline", pyac_logline, METH_VARARGS, "Adds a line to the log with the given loglevel."},
    {"getclient", pyac_getclient, METH_VARARGS, "Gets the client with the specified cn."},
    {"getallclients", (PyCFunction)pyac_getallclients, METH_NOARGS, "Gets all clients on the server."},
    {"sendmsg",pyac_sendmsg,METH_VARARGS,"Sends a message to a client, -1 (default) sends to all clients"},
    {"disconnect_client", pyac_discclient, METH_VARARGS, "Disconnects a client cn with reason."},
    {"forcesuicide", pyac_forceSuicide, METH_VARARGS, "Makes player suicide."},
    {NULL, NULL, 0, NULL}
};

void runCallback(const char *hname, PyObject *args) {
    for (Py_ssize_t i = 0; i<PyList_GET_SIZE(pyac_modules); i++) {
        PyObject *mod = PyList_GetItem(pyac_modules,i);
        PyObject *method = PyDict_GetItemString(mod,hname);
        if (method!=NULL) {
            PyObject *retval = PyObject_CallObject(method,args);
            if (retval==NULL) {
                PyErr_Print();
            }
            else {
                Py_DECREF(retval);
            }
        }
    }
    Py_XDECREF(args);
}
PyObject *runGetCallback(const char *hname, PyObject *args) {
    for (Py_ssize_t i = 0; i<PyList_GET_SIZE(pyac_modules); i++) {
        PyObject *mod = PyList_GetItem(pyac_modules,i);
        PyObject *method = PyDict_GetItemString(mod,hname);
        if (method!=NULL) {
            PyObject *retval = PyObject_CallObject(method,args);
            if (retval==NULL) {
                PyErr_Print();
            }
            else{
                return retval;
            }
        }
    }
    Py_XDECREF(args);
    return NULL;
}
bool runGetBoolCallback(const char *hname, PyObject *args, bool def) {
    bool retb;
    for (Py_ssize_t i = 0; i<PyList_GET_SIZE(pyac_modules); i++) {
        PyObject *mod = PyList_GetItem(pyac_modules,i);
        PyObject *method = PyDict_GetItemString(mod,hname);
        if (method!=NULL) {
            PyObject *retval = PyObject_CallObject(method,args);
            if (retval==NULL) {
                PyErr_Print();
            }
            else{
                if (PyObject_IsTrue(retval)!=def) def = !def;
                Py_DECREF(retval);
                return def;
            }
        }
    }
    Py_XDECREF(args);
    return def;
}

void initPython(char *name, bool dedicated) {
    PyObject *modname,*module,*dict, *submodule;
    
    Py_SetProgramName(name);
    Py_Initialize();
    
    PyRun_SimpleString("import sys\nsys.path.append('./pyac');sys.path.append('./pyac_library')");
//    conoutf("Python version:\n%s",Py_GetVersion());
    
    pyac_acmod = Py_InitModule3("assaultcube", pyac_MainMethods, "Module containing entrypoint and common features of assaultcube.");
    dict = PyModule_GetDict(pyac_acmod);
    if (!dedicated) {
        submodule = Py_InitModule3("assaultcube.client", pyac_ClientMainMethods, "Main module for clientside scripting.");
        PyModule_AddObject(pyac_acmod, "client", submodule);
    }
    else {
        submodule = Py_InitModule3("assaultcube.server", pyac_ServerMainMethods, "Main module for serverside scripting.");
        PyModule_AddIntConstant(submodule, "ACLOG_DEBUG", ACLOG_DEBUG);
        PyModule_AddIntConstant(submodule, "ACLOG_VERBOSE", ACLOG_VERBOSE);
        PyModule_AddIntConstant(submodule, "ACLOG_INFO", ACLOG_INFO);
        PyModule_AddIntConstant(submodule, "ACLOG_WARNING", ACLOG_WARNING);
        PyModule_AddIntConstant(submodule, "ACLOG_ERROR", ACLOG_ERROR);
        PyModule_AddIntConstant(submodule, "ACLOG_NUM", ACLOG_NUM);
        PyModule_AddObject(pyac_acmod, "server", submodule);
    }
    
    PyModule_AddObject(pyac_acmod, "dedicated", dedicated ? Py_True:Py_False);
    
    pyac_modules = PyList_New(0);
    
//    Py_InitModule("console", pyac_ConsoleMethods);
    
    PyModule_AddIntConstant(pyac_acmod,"version",AC_VERSION);
    PyModule_AddIntConstant(pyac_acmod,"protocol",PROTOCOL_VERSION);
    PyModule_AddStringConstant(pyac_acmod,"masterurl",AC_MASTER_URI);
    PyModule_AddIntConstant(pyac_acmod,"masterport",AC_MASTER_PORT);
    PyModule_AddIntConstant(pyac_acmod,"maxclients",MAXCL);
    
    PyModule_AddObject(pyac_acmod, "registeredcallbacks", pyac_modules);
    
    vector<char *> files;
    listfiles("pyac", "py", files);
    loopv(files) {
        modname = PyString_FromString(files[i]);
//        conoutf("Loading module %s",files[i]);
        
        module = PyImport_Import(modname);
        if (module==NULL) {
            PyErr_Print();
        }
        else {
            Py_DECREF(module);
        }
        
        Py_DECREF(modname);
    }
    runCallback("init",NULL);
}